ABOUT ZEN CLASSIC

  The Zen Classic theme contains the old stylesheets from Zen 5.x-0.7. It was
  made a sub-theme of Zen because, while the theme looked good as-is, everyone
  was tired of undoing all that CSS when using it to develop a new theme. See
  http://groups.drupal.org/node/6353 and http://drupal.org/node/171464

SUPPORT

  The Zen Classic theme is left as-is for historical purposes and as a reference
  for people who used Zen 5.x-0.7 and earlier and have gotten used to themeing
  with it.

  However, since most developers dislike using it as a starting point for theme
  development, fewer people will be available to help with themeing issues you
  may encounter.

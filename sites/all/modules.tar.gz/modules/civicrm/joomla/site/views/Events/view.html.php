<?php
  //////////////////////////////////////////////////
  // CiviCRM Front-end Profile - Presentation Layer
  //////////////////////////////////////////////////

defined('_JEXEC') or die('No direct access allowed'); 

// PUT ALL YOUR FRONT-END HTML CODE HERE...PRESENTATION

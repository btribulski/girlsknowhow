<?php
// escape early if called directly
defined('_JEXEC') or die('No direct access allowed'); 


  //////////////////////////////////////////////////
  // CiviCRM Front-end Profile - Presentation Layer
  //////////////////////////////////////////////////

// PUT ALL YOUR FRONT-END HTML CODE HERE...PRESENTATION

<?php
  //////////////////////////////////////////////////
  // CiviCRM Front-end Profile - Presentation Layer
  //////////////////////////////////////////////////

defined('_JEXEC') or die('No direct access allowed'); 
//pulling in the content of the file below.
//require_once ( JPATH_ADMINISTRATOR .DS.'components'.DS.'com_civicrm'.DS.'CRM'.DS.'Contact'.DS.'Page'.DS.'View'.DS.'UserDashBoard.php' );

// PUT ALL YOUR FRONT-END HTML CODE HERE...PRESENTATION


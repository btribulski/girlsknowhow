<?php
defined('_JEXEC') or die('No direct access allowed'); 

 //////////////////////////////////////////////////
  // CiviCRM Front-end Profile - Presentation Layer
  //////////////////////////////////////////////////

/**
 *
 * @package CRM
 * @copyright CiviCRM LLC (c) 2004-2009
 * $Id$
 *
 */


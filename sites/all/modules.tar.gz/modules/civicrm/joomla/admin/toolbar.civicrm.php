<?php 

defined('_JEXEC') or die('Restricted access'); 

require_once( JApplicationHelper::getPath( 'toolbar_html' ) );

TOOLBAR_civicrm::_DEFAULT( );   

?>
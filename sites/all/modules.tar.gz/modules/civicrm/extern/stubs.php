<?php

function user_access( $string ) {
    return true;
}

function module_list( ) {
    return array( );
}

